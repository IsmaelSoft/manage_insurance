Pour le déploiement de ce module:
-cloner le dépôt du module sur github 
-déposer le module dans le repertoire addans des modules personalisés
-se rassurer que le chemin vers le module est indiqué dans odoo.conf
-redémarer l'instance 
-lancer l'interface et chercher "manage_insurance dans la liste des application" et l'installer
